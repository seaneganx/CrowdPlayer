<?php
echo '<link rel="stylesheet" type="text/css" href="appCSS/styleQ.css"></head>';


if (!$link = mysql_connect('localhost', 'frozenbo_admin', 'abcd1234')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('frozenbo_crowd_player', $link)) {
    echo 'Could not select database';
    exit;
}

// get the song id from the URL
$song_id = $_GET['id'];
echo $song_id;

// insert the song into the database
// $sql    = 'INSERT INTO Songs (song_id, song_name, song_artist, vote_count) VALUES ();';
$base = '/app/vote.php?id=';
$upvote = '&value=1';
$downvote = '&value=-1';

$sql = 'SELECT * FROM Songs;';
$result = mysql_query($sql, $link);

if (!$result) {
    echo "DB Error, could not query the database\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}

echo "<body>";
echo "<h1>CrowdPlayer</h1>";
echo "<ul>";

while ($row = mysql_fetch_assoc($result)) {
$song_id = $row['song_id'];
$vote = $base . $song_id;

echo "<li>" . $row['song_name'] . " - " . $row['song_artist'] . "<b>Likes: " . $row['vote_count']  . "</b>" .
 "<a class=\"like\" href=\"" . $vote . $upvote . "\"><img class=\"resize\" src=\"images/like.png\" alt=\"Up\" /></a>" . "</li>";
echo "</li>";
}

echo "</ul>";
echo "</body>";
mysql_free_result($result);

?>