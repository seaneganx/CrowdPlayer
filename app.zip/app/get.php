<?php

if (!$link = mysql_connect('localhost', 'frozenbo_admin', 'abcd1234')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('frozenbo_crowd_player', $link)) {
    echo 'Could not select database';
    exit;
}

// get the song id from the URL
$song_id = $_GET['id'];

// insert the song into the database
$base = '/app/vote.php?id=';
$upvote = '&value=1';

$sql = 'SELECT * FROM Songs';
$result = mysql_query($sql, $link);

function getJSON($id, $name, $artist, $votes) {
	return '{' . '"song_id": "' . $id . '", ' . '"song_name": "' . $name . '", ' . '"song_artist": "' . $artist . '", ' . '"vote_count": ' . $votes . '}';
}

echo '{ "array": [';

$row = mysql_fetch_assoc($result);
if ($row) {
	echo getJSON($row['song_id'], $row['song_name'], $row['song_artist'], $row['vote_count']);
	$row = mysql_fetch_assoc($result);
}

while ($row) {
	echo ',' . getJSON($row['song_id'], $row['song_name'], $row['song_artist'], $row['vote_count']);
	$row = mysql_fetch_assoc($result);
}

echo ']}';

mysql_free_result($result);

?>
