<?php

if (!$link = mysql_connect('localhost', 'frozenbo_admin', 'abcd1234')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('frozenbo_crowd_player', $link)) {
    echo 'Could not select database';
    exit;
}

// get the song info from the URL
$song_id = $_GET['id'];

// insert the song into the database
$sql = 'DELETE FROM Songs WHERE song_id = \'' . $song_id . '\';';
$result = mysql_query($sql, $link);

if (!$result) {
    echo "DB Error, could not query the database\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}

mysql_free_result($result);

?>